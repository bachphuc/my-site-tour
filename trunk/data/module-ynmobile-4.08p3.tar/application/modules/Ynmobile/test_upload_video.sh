curl 'http://product-dev.younetco.com/mobile/se460/index.php?m=lite&name=api&module=ynmobile&request=video/upload' \
-F "video=@3mb.mp4" \
-F "token=8N0x3xYpepsayCjZ5Kzemw6X"

curl 'http://product-dev.younetco.com/mobile/se460/index.php?m=lite&name=api&module=ynmobile&request=video/upload' \
-F "video=@13mb.MOV" \
-F "token=8N0x3xYpepsayCjZ5Kzemw6X"