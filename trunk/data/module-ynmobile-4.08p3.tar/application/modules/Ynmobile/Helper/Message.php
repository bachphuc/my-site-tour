<?php

class Ynmobile_Helper_Message extends Ynmobile_Helper_Base{
    
    
}
