<?php

class Ynmobile_Helper_SimplePhoto extends Ynmobile_Helper_Base{
    
}
