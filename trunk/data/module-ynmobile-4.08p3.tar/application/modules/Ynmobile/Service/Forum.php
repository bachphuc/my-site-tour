<?php

class Ynmobile_Service_Forum extends Ynmobile_Service_Base{
    
    protected $module = 'forum';
    protected $mainItemType = 'forum';
    
}

