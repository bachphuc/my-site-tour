<?php

class Ynmobile_Api_Notification extends Ynmobile_Service_Notification{}
