<?php

class Ynmobile_Api_Album extends Ynmobile_Service_Music{
    
}
