<?php

class Ynmobile_Api_Search extends Ynmobile_Service_Search{
    
}
