<?php

class Ynmobile_Api_Message extends Ynmobile_Service_Message{
    
}
