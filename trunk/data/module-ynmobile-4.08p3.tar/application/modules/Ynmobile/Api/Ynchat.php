<?php

class Ynmobile_Api_Ynchat extends Ynmobile_Service_Ynchat{
	
}
