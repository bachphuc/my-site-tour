<?php

class Ynmobile_Model_DbTable_Maps extends Engine_Db_Table
{
	protected $_name = 'ynmobile_maps';
	protected $_rowClass = 'Ynmobile_Model_Map';

}
