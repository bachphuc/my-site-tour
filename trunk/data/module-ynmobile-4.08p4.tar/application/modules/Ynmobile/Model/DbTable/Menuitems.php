<?php
class Ynmobile_Model_DbTable_Menuitems extends Engine_Db_Table
{
	protected $_serializedColumns = array('params');
}
