<?php

class Ynmobile_Model_DbTable_Profilecovers extends Engine_Db_Table
{
	protected $_name = 'ynmobile_profilecovers';
	protected $_rowClass = 'Ynmobile_Model_Profilecover';
}
