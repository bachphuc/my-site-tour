<?php 
class Ynmobile_Model_Userdevice extends Core_Model_Item_Abstract
{
	protected $_searchTriggers = false;
}
