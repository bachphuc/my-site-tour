<?php
class Ynmobile_Model_Profilecover extends Core_Model_Item_Abstract
{
	protected $_searchTriggers = false;
}
