<?php
class Ynmobile_Model_Token extends Core_Model_Item_Abstract
{
	protected $_searchTriggers = false;
}
