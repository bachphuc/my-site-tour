<?php

class Ynmobile_Api_Blog extends Ynmobile_Service_Blog{}
