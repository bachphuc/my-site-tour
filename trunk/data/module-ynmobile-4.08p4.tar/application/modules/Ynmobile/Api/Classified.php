<?php

class Ynmobile_Api_Classified extends  Ynmobile_Service_Classified{
    
}
