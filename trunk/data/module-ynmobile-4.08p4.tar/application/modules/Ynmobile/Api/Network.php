<?php

class Ynmobile_Api_Network extends Ynmobile_Service_Network{}
