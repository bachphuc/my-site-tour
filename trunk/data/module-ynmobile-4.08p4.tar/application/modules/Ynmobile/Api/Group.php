<?php

class Ynmobile_Api_Group extends Ynmobile_Service_Group {

}