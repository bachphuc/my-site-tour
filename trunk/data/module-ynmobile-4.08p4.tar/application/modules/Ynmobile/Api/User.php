<?php

class Ynmobile_Api_User extends Ynmobile_Service_User{}
