<?php

class Ynmobile_Api_Feed extends Ynmobile_Service_Feed{}
