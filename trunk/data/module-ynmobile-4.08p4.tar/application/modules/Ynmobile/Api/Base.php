<?php

class Ynmobile_Api_Base extends Ynmobile_Service_Base{
    
}
