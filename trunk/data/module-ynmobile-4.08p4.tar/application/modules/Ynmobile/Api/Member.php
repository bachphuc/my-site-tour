<?php 

class Ynmobile_Api_Member extends Ynmobile_Service_Member{
    
}
