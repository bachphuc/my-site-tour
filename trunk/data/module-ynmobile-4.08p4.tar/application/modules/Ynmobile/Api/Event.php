<?php

class Ynmobile_Api_Event extends Ynmobile_Service_Event{};

