<?php
/**
 * SocialEngine
 *
 * @category   Application_Ynmobile
 * @package    Ynmobile
 * @copyright  Copyright 2013-2013 YouNet Company
 * @license    http://socialengine.younetco.com/
 * @version    $Id: Comment.php minhnc $
 * @author     MinhNC
 */

class Ynmobile_Api_Comment extends Ynmobile_Service_Comment
{
    
}
