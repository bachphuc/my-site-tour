<?php

class Ynmobile_Api_Friend extends Ynmobile_Service_Friend{
    
}
