<?php
class Ynmobile_Api_Photo extends Ynmobile_Service_Photo
{
    
}
