<?php
/**
*
* @category   Application_Ynmobile
* @package    Ynmobile
* @copyright  Copyright 2014 YouNet Company
* @license    http://socialengine.younetco.com
* @author     LongL
*/

class Ynmobile_Api_Poll extends Ynmobile_Service_Poll{
	
}