<?php
class Ynmobile_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}

?>