<?php
defined('PHPFOX') or exit('NO DICE!');
?>

<div class="bt_select_tag"></div>
<div class='display_block' style='display: none;'>
    <div id="popup_selector">Selector: <input type="text" style="width: 200px;"></div>
</div>