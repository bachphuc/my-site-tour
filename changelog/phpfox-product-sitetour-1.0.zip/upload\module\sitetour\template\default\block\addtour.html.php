<?php
    defined('PHPFOX') or exit('NO DICE!');
?>


<div class="block_add_newtour">
    <ul class="new_tour_menu">
        <li class="bt_add_new_tour">Add New Tour</li>
        <li class="bt_preview_tour">Preview Tour</li>
        <li class="bt_stop_setup_tour">Stop Setup Tour</li>
        <li>Save Tour</li>
        <li>Cancel Tour</li>
    </ul>
</div>