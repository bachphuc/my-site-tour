<?php
    defined('PHPFOX') or exit('NO DICE!');
    phpfox::getLib('template')->setHeader(array(
        'bootstrap-tour-standalone.min.css' => 'module_sitetour',
        'bootstrap-tour-standalone.js' => 'module_sitetour',
        'jquery.dom-outline-1.0.js' => 'module_sitetour',
        'sitetour.js' => 'module_sitetour',
        'sitetour.css' => 'module_sitetour',
    ));
?>
